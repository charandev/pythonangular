import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

const AUTH_API = 'https://amsmlpipe3.mindtree.com/intelyzers/login';
let authorizationData = 'Basic ' + btoa('intelyzer.admin:intelyzeradmin123');
const headerOptions = {
  headers: new HttpHeaders({
      'Content-Type':  'application/json',
      'Authorization': authorizationData
  })
};

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  login(credentials): Observable<any> {
    return this.http.get(AUTH_API,  headerOptions )
  };

  getage():Observable<any> {
    return this.http.get("https://api.agify.io/?name=charan&country_id=IN");
  }

  // register(user): Observable<any> {
  //   return this.http.post(AUTH_API + 'signup', {
  //     username: user.username,
  //     email: user.email,
  //     password: user.password
  //   }, httpOptions);
  // }
}
